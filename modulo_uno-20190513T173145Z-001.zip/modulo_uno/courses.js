const courses = [
  {
    id: 1,
    name: 'Curso básico de HTML y CSS',
    duration: 128,
    price: 120000
  },
  {
    id: 2,
    name: 'Curso de JavaScript',
    duration: 64,
    price: 150000
  },
  {
    id: 3,
    name: 'Curso de NodeJS',
    duration: 32,
    price: 70000
  }
];

module.exports = courses;
