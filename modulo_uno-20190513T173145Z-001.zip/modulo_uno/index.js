const fs = require('fs');
const cursos = require('./courses');
const opciones = {
  id: {
    demand: true,
    describe: 'ID del curso',
    alias: 'i'
  },
  nombre: {
    demand: true,
    describe: 'Nombre del interesado',
    alias: 'n'
  },
  cedula: {
    demand: true,
    describe: 'Cédula del interesado',
    alias: 'c'
  }
};
let isCreated = false;
const argv = require('yargs').command(
  'inscribir',
  'Proceso de inscripción',
  opciones,
  (crearArchivo = argv => {
    let curso = cursos.find(item => item.id == argv.id);
    if (curso == undefined) {
      console.log('Ha ingresado un ID que no corresponde a ningún curso.');
    } else {
      texto =
        'El estudiante ' +
        argv.nombre +
        '\n' +
        'con cédula ' +
        argv.cedula +
        '\n' +
        'se ha matriculado en el curso llamado "' +
        curso.name +
        '", con una duración de ' +
        curso.duration +
        ' horas y un valor de $' +
        curso.price +
        ' pesos';
      fs.writeFile('matricula.txt', texto, err => {
        if (err) console.log(err);
        console.log('Se ha creado el archivo');
      });
      isCreated = true;
    }
  })
).argv;

if (isCreated == false) {
  let matriculas = (oferta, callback) => {
    let time = 0;
    oferta.forEach(curso => {
      setTimeout(() => {
        callback(curso);
      }, (time += 2000));
    });
  };

  matriculas(cursos, listado =>
    console.log(
      `El curso "${listado.name}", con el ID ${
        listado.id
      }, tiene una duración de ${listado.duration} y un valor de ${
        listado.price
      }.`
    )
  );
}
